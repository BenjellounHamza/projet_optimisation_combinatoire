/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ensimag.projetspe;
import java.util.ArrayList;
import org.apache.commons.collections4.iterators.PermutationIterator;
/**
 *
 * @authors 
 */
public class Main {
    public static void main(String[] args){
    	//Tester test = new Tester();
        //test.test();
        Matrix m = new Matrix(10, 0.5);
        //Matrix m = new Matrix("./test/matrix-10-0.5");
        m.printMatrix();        
        
        BranchAndBound bb = new BranchAndBound(m);
        bb.execute();
        m.printMatrix();
        System.out.println(m.maxTriangleSize());
        System.out.println();
        

    }
}
