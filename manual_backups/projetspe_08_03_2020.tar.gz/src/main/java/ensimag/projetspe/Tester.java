package ensimag.projetspe;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Tester {
	public void test() {
		File dir = new File("./test");
		File[] directoryListing = dir.listFiles();
		 try {
	            PrintWriter writer = new PrintWriter("Log.csv", "UTF-8");
	            writer.println("Size,Density,LowerBound,TriangleMax,UpperBound");
	            String str;
	    		for(File child: directoryListing) {
	    			Matrix m = new Matrix(child.getAbsolutePath());
	    			//algo
	    			BranchAndBound algo = new BranchAndBound(m);
                                algo.execute();

                                str = "";
	    			str = str + Integer.toString(m.getNbColumns()) 
                                        + "," + Integer.toString((int)
                                                (100*m.getDensity())) + ","
	    			      + Integer.toString(m.getLowerBound()) +
                                      "," + Integer.toString(m.maxTriangleSize())
                                        + "," + Integer.toString(m.getUpperBound()) + "\n";
	    			writer.print(str);
                                System.out.println("done for matrix" + 
                                        Integer.toString(m.getNbColumns()) +
                                        "," + Integer.toString((int)(100*m.getDensity())));
	    		}
	            writer.close();
	        } catch (FileNotFoundException | UnsupportedEncodingException ex) {
	            System.out.println("ERROR");
	            Logger.getLogger(Matrix.class.getName()).log(Level.SEVERE, null, ex);
	        }   
	}
}
