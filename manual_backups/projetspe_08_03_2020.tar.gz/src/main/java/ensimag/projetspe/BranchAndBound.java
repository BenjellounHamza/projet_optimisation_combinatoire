/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ensimag.projetspe;
import java.util.Scanner;
import java.util.ArrayList;
import static java.util.Collections.reverseOrder;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import static java.util.Map.Entry.comparingByValue;
import static java.util.stream.Collectors.toMap;

/**
 *
 * @author omar
 */
public class BranchAndBound {
    
    private final Matrix matrix;
    
    public BranchAndBound(Matrix matrix){
        this.matrix = matrix;
    }
    
    public int lowerBound;
    public int upperBound;
        
    
    public void lineMax(int iline, int jcolumn, int rank){
        //generalizes lineMax(int, int) but with the line with the k-th (k=rank)
        //maximum sub white count. time complexity : O(nlogn)
        HashMap<Integer, Integer> map = new HashMap<>();
            int compteur = 0;
            for(int i = iline; i<matrix.getNbRows(); i++) {
                    map.put(compteur, matrix.getRow(i).getNbWhitesSub(jcolumn));
                    compteur++;
            }
	    Map<Integer, Integer> sorted = map
	            .entrySet()
	            .stream()
	            .sorted(comparingByValue(reverseOrder()))
	            .collect(
	                toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2,
	                    LinkedHashMap::new));
	    //matrix.setPermutRows(new ArrayList<>( sorted.keySet()));
            matrix.permutRows(iline, new ArrayList<>(sorted.keySet()).get(rank));
    }
    
    public void lineMax(int iline, int jcolumn){
        // swaps the iline line with the line with maximum sub white count
        //(using jcolumn) in the [iline, nbRows] lines
        int cMax = 0; int indexMax = -1;
        int c;
        for (int i = iline; i<matrix.getNbRows(); i++){
            Line line = matrix.getRow(i);
            c = line.getNbWhitesSub(jcolumn);
            if (c>cMax){
                cMax = c; indexMax = i;
            }
        }
        if (indexMax!=-1){
            matrix.permutRows(iline, indexMax);
        }
    }
     
    public void reorganizeColumns(int iline, int jcolumn){
        //reorganizes columns such that we maximize the count
        //of whites starting from the right for the i th line
        //whilst ignoring cells in [0,jcolumn[
        Line line = matrix.getRow(iline);
        int start = line.getElements().size()-1;
        int end = jcolumn;
        int startSearch; int endSearch;
        while (start>end){
            if (line.getElements().get(start)){
                //swap with the first 0 beginning from the "end"
                startSearch = end; endSearch = start;
                while (line.getElements().get(startSearch)
                        && startSearch<endSearch ){
                    startSearch++;
                }
                if (startSearch<endSearch){//we swap!
                    matrix.permutColumns(startSearch, endSearch);
                    assert(startSearch>=jcolumn); assert(endSearch>=jcolumn);
                    line = matrix.getRow(iline);
                }
            }
            start--;
        }
    }
    
    public void execute(){
        Node tmp;
        Node racine = new Node(null);
        lineMax(0,0);
        reorganizeColumns(0,0);
        Node currentFils = new Node(racine);
        currentFils.depth = 0;
        currentFils.nbWhites = matrix.getRow(0).getNbWhitesSub(0);
        racine.children.add(currentFils);
        while (true){
            if (currentFils.depth == matrix.getNbRows()-1 ||
                    currentFils.nbWhites == 0){
                //arrivé a une feuille
                currentFils = new Node(currentFils.parent);
                currentFils.parent.children.add(currentFils);
                break;
            }else{
                lineMax(currentFils.depth+1,
                        matrix.getNbRows()-currentFils.nbWhites);
                reorganizeColumns(currentFils.depth+1,
                        matrix.getNbRows()-currentFils.nbWhites);
                tmp = currentFils;
                currentFils = new Node(currentFils);
                currentFils.nbWhites = matrix.getRow(tmp.depth+1)
                        .getNbWhitesSub(matrix.getNbRows()- tmp.nbWhites+1);
                tmp.children.add(currentFils);
            }
        }
        racine.print();
    }
    
    
    /*public void execute(){
        int cpti=0; int cptj=0;
        int cptjnew;
        upperBound = matrix.getNbRows();
        while(true){
            lineMax(cpti, cptj);
            reorganizeColumns(cpti, cptj);
            cptjnew = matrix.getNbRows()- matrix.getRow(cpti).getNbWhitesSub(cptj);
            cptj = cptjnew;
            cpti++;
            if (cptj >= matrix.getNbRows()-1 || cpti>=matrix.getNbColumns()-1){
                break;
            }
        }
    }*/
    
}
