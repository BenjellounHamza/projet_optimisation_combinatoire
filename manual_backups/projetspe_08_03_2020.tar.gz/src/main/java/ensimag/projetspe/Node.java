/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ensimag.projetspe;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author omar
 */
public class Node {
    Node parent;
    ArrayList<Node> children;
    int depth;
    int nbWhites;
    int oldPos;
    public Node(Node parent){
        this.parent = parent;
        children = new ArrayList<>();
        if (parent == null){
            this.depth = 0;
        }else{
            this.depth = parent.depth +1;
        }
    }
    public Node(Node parent, int nbWhites, int oldPos){
        this(parent);
        this.nbWhites = nbWhites;
        this.oldPos = oldPos;
    }
    
    public void print(){
        print(this, 0);
    }
    
    private void print(Node self, int indent){
        //prints node and all children of the node
        String s = "";
        for (int i = 0; i<indent; i++){
            s+=' ';
        }
        System.out.println(s+self.nbWhites);       
        for (Node c : self.children){
            c.print(c, indent+1);  
        }
    }
    
    
    public void dfs(Node node){
        if (node != null){
            node.print();
            for (Node child : node.children){
                dfs(node);
            }
        }
    }
    
    public Iterator<Node> DFS(Node racine){
        Node current = racine;
        Iterator<Node> it = new Iterator<Node>(){
            @Override
            public boolean hasNext(){
                return true;
            }
            @Override
            public Node next(){
                if (current != null){
                    
                }
                
                return new Node(null);
            }
        };
        return it;
    }
}
