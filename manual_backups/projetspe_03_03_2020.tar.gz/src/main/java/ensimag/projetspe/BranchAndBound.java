/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ensimag.projetspe;

import java.util.ArrayList;

/**
 *
 * @author omar
 */
public class BranchAndBound {
    
    private Matrix matrix;
    
    public BranchAndBound(Matrix matrix){
        this.matrix = matrix;
        linesLeft = new ArrayList<>();
        for (int i = 0; i<matrix.getNbColumns(); i++){
            linesLeft.add(i);
        }
    }
    
    public int lowerBound;
    public int upperBound;
    
    public ArrayList<Integer> linesLeft;//indexes of lines left
    
    
    public int lineMax(int iline){
        // return index of the line with maximum white count
        // in the [iline, nbRows] lines (sub matrix)
        int cMax = 0; int indexMax = -1;
        int c;
        for (int i : linesLeft){
            Line line = matrix.getRow(i);
            c = line.getNbWhitesSub(line.getElements().size()
                    - upperBound);
            if (c>cMax){
                cMax = c; indexMax = i;
            }
        }
        return indexMax;
    }
     
    public void reorganizeColumns(int index){
        //reorganizes columns such that we maximize the count
        //of whites starting from the right for the i th line
        // NB: all of this given the upper bound, of course!
        Line line = matrix.getRow(index);
        int start = line.getElements().size()-1;
        int end = line.getElements().size()-upperBound;
        int startSearch; int endSearch;
        while (start>end){
            if (line.getElements().get(start)){
                //swap with the first 0 beginning from the "end"
                startSearch = end; endSearch = start;
                while (line.getElements().get(startSearch)
                        && startSearch<endSearch ){
                    startSearch++;
                }
                if (startSearch<endSearch){//we swap!
                    matrix.permutColumns(startSearch, endSearch);
                    line = matrix.getRow(index);
                }
            }
            start--;
        }
    }
    
    public void execute(){
        lowerBound = 0;
        upperBound = matrix.getNbRows();
        int cpt = 0;
        int lineMax;
        int bool;
        while (lowerBound < upperBound || !linesLeft.isEmpty()){
            lineMax = lineMax();
            matrix.permutRows(cpt, lineMax);
            System.out.println("lineMax");
            matrix.printMatrix();
            reorganizeColumns(cpt);
            System.out.println("reorganize");
            matrix.printMatrix();
            bool = linesLeft.remove(lineMax); bool++;//whatever
            System.out.println("linesLeft");
            System.out.println(linesLeft.toString());
            cpt++;
        }
    }
    
}
