/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ensimag.projetspe;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.io.*;
import java.util.Scanner;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @authors Spec
 */
public class Matrix {
    
    private int nbRows;
    private int nbColumns;
    private double density;
   
    public int getNbRows() {
        return nbRows;
    }

    public int getNbColumns() {
        return nbColumns;
    }
    
    public ArrayList<Line> getLines() {
		return lines;
	}

	public ArrayList<Line> getColumns() {
		return columns;
	}

	public double getDensity() {
        return density;
    }
    
    private ArrayList<Line> lines;
    private ArrayList<Line> columns;
    
    public Matrix(int dimension){
        this(dimension, dimension, (new Random()).nextDouble());
    }
    
    public Matrix(int dimension, double density){
        this(dimension, dimension, density);
    }
    
    public Matrix(int nbRows, int nbColumns, double density){
        assert(density>=0 && density<=1);
        this.nbColumns = nbColumns; this.nbRows = nbRows; this.density = density;
        lines = new ArrayList<>();
        columns = new ArrayList<>();
        ArrayList<Boolean> line; 
        ArrayList<Boolean> column;
        Boolean bool;
        Random rand = new Random();
        for (int j = 0; j<nbColumns; j++){
            columns.add(new Line(new ArrayList<>()));
        }
        for (int j = 0; j<nbColumns; j++){
            line = new ArrayList<>();
            for (int i = 0; i<nbRows; i++){
                 bool = rand.nextDouble()>density;
                 line.add(bool);
                 columns.get(i).add(bool);
             }
            lines.add(new Line(line));
        }
        this.initPermut();
    }
    public Matrix(ArrayList<Line> lines){
        this.modifMatrix(lines);
    }
    private void modifMatrix(ArrayList<Line> lines){
        this.lines = lines;
        this.columns = new ArrayList<>();
        this.nbRows = lines.size();
        this.nbColumns = lines.get(0).getElements().size();
        int nbWhites = 0;
        ArrayList<Boolean> line; 
        for (int j = 0; j<nbColumns; j++){
            columns.add(new Line(new ArrayList<>()));
        }
        for (int j = 0; j<nbRows; j++){
            line = lines.get(j).getElements();
            nbWhites += lines.get(j).getNbWhites();
            for (int i = 0; i<nbColumns; i++){
                 columns.get(i).add(line.get(i));
             }
        }
        this.density = (double)nbWhites/(nbRows*nbColumns);
        this.initPermut();
    }
    
    
    public Matrix(String fileName){//reads file and constructs the matrix
        try {
            Scanner scanner = new Scanner(new File(fileName));
            ArrayList<Line> lines = new ArrayList<>();
            ArrayList<Boolean> line;
            while (scanner.hasNextLine()){
                String sline = scanner.nextLine();
                String [] elements = sline.split(" ");
                line = new ArrayList<>();
                for (String element : elements) {
                    line.add(Integer.parseInt(element) == 1);
                }
                lines.add(new Line(line));
            }
            this.modifMatrix(lines);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Matrix.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private ArrayList<Integer> permutRows;
    private ArrayList<Integer> permutColumns;

    public ArrayList<Integer> getPermutRows() {
        return permutRows;
    }

    public void setPermutRows(ArrayList<Integer> permutRows) {
        this.permutRows = permutRows;
    }

    public ArrayList<Integer> getPermutColumns() {
        return permutColumns;
    }

    public void setPermutColumns(ArrayList<Integer> permutColumns) {
        this.permutColumns = permutColumns;
    }
    private void initPermut(){
        this.permutRows = new ArrayList<>();
        for(int i = 0; i < nbRows; i++){
            this.permutRows.add(i);
        }
        this.permutColumns = new ArrayList<>();
        for(int i = 0; i < nbColumns; i++){
            this.permutColumns.add(i);
        }
    }
    public void printMatrix(){
        for (int i = 0; i < nbRows; i++){
            this.getRow(i).printLine();
        }
        System.out.println();
    }
    public Line getRow(int i){
        Line L = this.lines.get(this.permutRows.get(i));
        ArrayList<Boolean> newL = new ArrayList<>();
        for(int j = 0; j < L.getElements().size(); j++){
            newL.add(L.getElements().get(permutColumns.get(j)));
        }
        return new Line(newL);
    }
    public Line getColumn(int i){
        Line C = this.columns.get(this.permutColumns.get(i));
        ArrayList<Boolean> newC = new ArrayList<>();
        for(int j = 0; j < C.getElements().size(); j++){
            newC.add(C.getElements().get(this.permutRows.get(j)));
        }
        return new Line(newC);
    }
    public boolean getElement(int i, int j){
        Line L = this.lines.get(this.permutRows.get(i));
        return L.getElements().get(this.permutColumns.get(j));
    }
    
    public int maxTriangleSize(){
        int max = -1;
        Boolean bool = true;
        int currentI = 0;
        int currentJ = nbColumns - 1;
        while(bool){
        	max += 1;
            while(currentJ < nbColumns){
                if(this.getElement(currentI, currentJ)){
                    bool = false;
                    break;
                }
                currentJ += 1;
                currentI += 1;
            }
            currentJ = nbColumns - (currentI + 1);
            currentI = 0;
        }
        return max;
    }
    public void permutRows(int i, int j) {
    	this.permutRows.set(i, j);
    	this.permutRows.set(j, i);
    }
    public void permutColumns(int i, int j) {
    	this.permutColumns.set(i, j);
    	this.permutColumns.set(j, i);
    }
    public void printFile(String fileName){
        try {
            PrintWriter writer = new PrintWriter(fileName, "UTF-8");
            for (Line line : lines){
                for (Boolean element : line.getElements()){
                    if (element){
                        writer.print(1);
                    }
                    else{
                        writer.print(0);
                    }
                    writer.print(" ");
                }
                writer.println();
            }
            writer.close();
        } catch (FileNotFoundException | UnsupportedEncodingException ex) {
            System.out.println("ERROR");
            Logger.getLogger(Matrix.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    public int getUpperBound() {
    	ArrayList<Integer> sortedWhites = new ArrayList<>();
    	for(Line L : this.lines) {
    		sortedWhites.add(L.getNbWhites());
    	}
        Collections.sort(sortedWhites, Collections.reverseOrder());
    	int max = sortedWhites.get(0);
    	int compteur = 1;
    	Boolean bool = true;
    	while(bool) {
    		while(compteur <= max && compteur < sortedWhites.size()) {
    			if(sortedWhites.get(compteur) < sortedWhites.get(compteur) - 1) {
    				break;
    			}
    			compteur++;
    		}
    		if(compteur > max) {
    			bool = false;
    			break;
    		}
    		compteur = 1;
    		max -= 1;
    	}
    	return max;
    }
    public int getLowerBound() {
    	return 0; // for now..
    }
}
