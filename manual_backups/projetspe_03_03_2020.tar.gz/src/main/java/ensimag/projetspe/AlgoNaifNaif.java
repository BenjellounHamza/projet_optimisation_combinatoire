/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ensimag.projetspe;

import java.util.ArrayList;
import org.apache.commons.collections4.iterators.PermutationIterator;


/**
 *
 * @author omar
 */
public class AlgoNaifNaif {
    private Matrix matrix;
	
	public Matrix getMatrix() {
		return matrix;
	}

	public AlgoNaifNaif(Matrix matrix) {
		this.matrix = matrix;
	}
	
	
	public void execute() {
		final PermutationIterator<Integer> pr, pc;
                pr = new PermutationIterator<Integer>(matrix.getPermutRows());
                pc = new PermutationIterator<Integer>(matrix.getPermutColumns());
                ArrayList<Integer> rtmp, ctmp;
                int tailleMax;
                while (pr.hasNext()){
                    while (pc.hasNext()){
                        rtmp = matrix.getPermutRows();//sauvegarde des anciens
                        ctmp = matrix.getPermutColumns();
                        tailleMax = matrix.maxTriangleSize();
                        
                        matrix.setPermutRows((ArrayList<Integer>) pr.next());
                        matrix.setPermutColumns((ArrayList<Integer>) pc.next());
                        if (matrix.maxTriangleSize()<=tailleMax){
                            //reverting back
                            matrix.setPermutRows(rtmp);
                            matrix.setPermutColumns(ctmp);
                        }
                    }
                }
	}

}
