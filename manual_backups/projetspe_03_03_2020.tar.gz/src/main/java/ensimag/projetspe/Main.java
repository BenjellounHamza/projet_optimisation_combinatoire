/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ensimag.projetspe;
import java.util.ArrayList;
import org.apache.commons.collections4.iterators.PermutationIterator;
/**
 *
 * @authors 
 */
public class Main {
    public static void main(String[] args){
    	//Tester test = new Tester();
    	//test.test();
        Matrix m = new Matrix(8, 0.4);
        m.printMatrix();
        BranchAndBound bb = new BranchAndBound(m);
        bb.upperBound = 8;
        bb.linesLeft = new ArrayList<>();
        for (int i =4; i<8; i++){
            bb.linesLeft.add(i);
        }
       // m.permutRows(0, bb.lineMax());
        m.printMatrix();
        


        //bb.execute();
    }
}
